#! /usr/bin/env python3 
 
# Import the Python library for ROS 
import rospy, time 
from geometry_msgs.msg import Twist 
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Bool
 
def scan_callback(msg): 
    global range_front 
    global range_right 
    global range_left 
    global ranges 
    global min_front,i_front, min_right,i_right, min_left ,i_left 
     
    ranges = msg.ranges 
    # get the range of a few points 
    # in front of the robot (between 5 to -5 degrees) 
    range_front[:5] = msg.ranges[5:0:-1]   
    range_front[5:] = msg.ranges[-1:-5:-1] 
    # to the right (between 300 to 345 degrees) 
    range_right = msg.ranges[300:345] 
    # to the left (between 15 to 60 degrees) 
    range_left = msg.ranges[60:15:-1] 
    # get the minimum values of each range  
    # minimum value means the shortest obstacle from the robot 
    min_range,i_range = min( (ranges[i_range],i_range) for i_range in range(len(ranges)) ) 
    min_front,i_front = min( (range_front[i_front],i_front) for i_front in range(len(range_front)) ) 
    min_right,i_right = min( (range_right[i_right],i_right) for i_right in range(len(range_right)) ) 
    min_left ,i_left  = min( (range_left [i_left ],i_left ) for i_left  in range(len(range_left )) ) 
     
 
# Initialize all variables 
range_front = [] 
range_right = [] 
range_left  = [] 
min_front = 0 
i_front = 0 
min_right = 0 
i_right = 0 
min_left = 0 
i_left = 0 
 
 
 
# Create the node 
cmd_vel_pub = rospy.Publisher('cmd_vel', Twist, queue_size = 1) # to move the robot 
scan_sub = rospy.Subscriber('scan', LaserScan, scan_callback)   # to read the laser scanner 
rospy.init_node('obstacle_detector') 
obs = rospy.Publisher('/obstacle_detected', Bool, queue_size=10)
 
         
rate = rospy.Rate(10) 
time.sleep(1) # wait for node to initialize 

while(not rospy.is_shutdown()):
    b = Bool()
    b.data = True if min_front < 2.0 else False
    obs.publish(b)
    rate.sleep()


